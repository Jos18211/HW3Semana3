import { createTheme } from '@mui/material/styles';
export const appTheme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#1a237e',
    },
    secondary: {
      main: '#00c853',
    },
  },
});
